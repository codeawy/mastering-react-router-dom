export const LEARN_NAV_ITEMS = [
  {
    text: "Quick Start",
    to: "/learn",
  },
  {
    text: "Thinking in React",
    to: "/learn/thinking-in-react",
  },
  {
    text: "Installation",
    to: "/learn/installation",
  },
];

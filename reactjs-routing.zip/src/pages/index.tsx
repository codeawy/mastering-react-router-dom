const HomePage = () => {
  return (
    <div>
      <h2>HomePage</h2>
    </div>
  );
};

export default HomePage;

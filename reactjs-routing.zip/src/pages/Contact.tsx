const ContactPage = () => {
  return (
    <div>
      <h2>Contact Page</h2>
    </div>
  );
};

export default ContactPage;

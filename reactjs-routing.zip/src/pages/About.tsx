const AboutPage = () => {
  return (
    <div>
      <h2>AboutPage</h2>
    </div>
  );
};

export default AboutPage;
